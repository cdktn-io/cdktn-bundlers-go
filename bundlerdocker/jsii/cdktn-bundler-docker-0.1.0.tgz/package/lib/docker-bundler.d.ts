import { BundleOptions, BundleOutputType, BundleResult, IAssetBundler } from "cdktn";
/**
 * Where the asset source is mounted inside the build container.
 */
export declare const BUNDLING_INPUT_DIR = "/asset-input";
/**
 * Where the build container writes its output.
 */
export declare const BUNDLING_OUTPUT_DIR = "/asset-output";
/**
 * How the source and output cross the host/container boundary.
 */
export declare enum BundlingFileAccess {
    /**
     * Bind-mount the host source and output directories into the container.
     *
     * The fastest option, but requires the host paths to be shareable with the
     * docker daemon.
     */
    BIND_MOUNT = "bind-mount",
    /**
     * Copy the source into a named volume, run the build, then copy the output
     * back out.
     *
     * Works where bind mounts are unavailable (e.g. a remote docker daemon).
     */
    VOLUME_COPY = "volume-copy"
}
/**
 * Configuration for {@link DockerBundler}.
 */
export interface DockerBundlerProps {
    /**
     * The image to run the build in, as a registry reference.
     *
     * Locally built images are not supported; build and push the image first.
     */
    readonly image: string;
    /**
     * The command to run in the container, as an argv array.
     *
     * The command reads the source from `/asset-input` and writes the built
     * artifact to `/asset-output`.
     */
    readonly command: string[];
    /**
     * The shape of the artifact the command writes to `/asset-output`.
     *
     * `DIRECTORY` stages the output directory. `FILE` requires the command to
     * write exactly one file and stages that file.
     *
     * @default - `FILE` when `outputFileName` is set, otherwise `DIRECTORY`
     */
    readonly outputType?: BundleOutputType;
    /**
     * The file name to stage a single-file artifact under.
     *
     * Only meaningful when the result is a single file staged as
     * `AssetType.FILE`.
     *
     * @default - the basename of the asset source path
     */
    readonly outputFileName?: string;
    /**
     * The user to run the container as.
     *
     * @default - the current host uid:gid
     */
    readonly user?: string;
    /**
     * Environment variables to set in the container.
     *
     * @default - no extra environment
     */
    readonly environment?: {
        [key: string]: string;
    };
    /**
     * Override the image entrypoint.
     *
     * @default - the image's default entrypoint
     */
    readonly entrypoint?: string[];
    /**
     * The working directory inside the container.
     *
     * @default "/asset-input"
     */
    readonly workingDirectory?: string;
    /**
     * The container network to attach to.
     *
     * @default - the default docker network
     */
    readonly network?: string;
    /**
     * The platform to run the container as.
     *
     * @default - the host platform
     */
    readonly platform?: string;
    /**
     * A `--security-opt` value passed to the container.
     *
     * @default - none
     */
    readonly securityOpt?: string;
    /**
     * How the source and output cross the host/container boundary.
     *
     * @default BundlingFileAccess.BIND_MOUNT
     */
    readonly bundlingFileAccess?: BundlingFileAccess;
    /**
     * The image used for the short-lived helper container that seeds the input
     * volume and fixes volume ownership under `VOLUME_COPY`.
     *
     * The build image is reused by default, so no second image is pulled and the
     * caller controls every reference the bundler touches. Override this only
     * when the build image has no POSIX shell or `chown` (e.g. a `scratch`- or
     * distroless-based image), pointing it at any small image that does.
     *
     * Ignored under `BIND_MOUNT`.
     *
     * @default - the build image
     */
    readonly volumeCopyHelperImage?: string;
}
/**
 * Runs a build inside a docker container and stages its output as a CDK for
 * Terraform asset.
 *
 * The build runs in an image the caller specifies, isolated from the host
 * toolchain, which makes the artifact reproducible across machines that share
 * the same image. The source directory is mounted read-only at `/asset-input`
 * under `BIND_MOUNT`, or copied into a named volume under `VOLUME_COPY`. The
 * build writes to `/asset-output`. File sources are not supported.
 *
 * `bundle` declines when the docker binary is missing or not executable, so a
 * `ChainBundler` falls through to the next bundler.
 */
export declare class DockerBundler implements IAssetBundler {
    readonly bundlerKey?: string;
    readonly outputFileName?: string;
    private readonly props;
    private readonly fileAccess;
    private readonly outputType;
    constructor(props: DockerBundlerProps);
    bundle(options: BundleOptions): BundleResult;
    private bindMount;
    private volumeCopy;
    private helperOptions;
    private tryRemove;
    private resolveUser;
}
