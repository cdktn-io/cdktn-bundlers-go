/**
 * Result of a docker invocation.
 */
export interface DockerExecResult {
    /**
     * The process exit status.
     */
    readonly status: number;
    /**
     * The captured standard output.
     */
    readonly stdout: string;
}
/**
 * A single docker container filesystem mount.
 */
export interface DockerVolume {
    /**
     * Absolute path on the host.
     */
    readonly hostPath: string;
    /**
     * Absolute path inside the container.
     */
    readonly containerPath: string;
    /**
     * Mount the path read-only.
     *
     * @default false
     */
    readonly readOnly?: boolean;
}
/**
 * A named docker volume mounted into a container.
 */
export interface DockerNamedVolume {
    /**
     * The volume name.
     */
    readonly name: string;
    /**
     * Absolute path inside the container.
     */
    readonly containerPath: string;
    /**
     * Mount the volume read-only.
     *
     * @default false
     */
    readonly readOnly?: boolean;
}
/**
 * Options for {@link DockerImage.run}.
 */
export interface DockerRunOptions {
    /**
     * The command to run in the container, as an argv array.
     *
     * @default - the image's default command
     */
    readonly command?: string[];
    /**
     * The user to run the container as (`-u`).
     *
     * @default - the image's default user
     */
    readonly user?: string;
    /**
     * Environment variables to set in the container.
     *
     * @default - no extra environment
     */
    readonly environment?: {
        [key: string]: string;
    };
    /**
     * Override the image entrypoint.
     *
     * @default - the image's default entrypoint
     */
    readonly entrypoint?: string[];
    /**
     * The working directory inside the container (`-w`).
     *
     * @default - the image's default working directory
     */
    readonly workingDirectory?: string;
    /**
     * Bind mounts to attach to the container.
     *
     * @default - no bind mounts
     */
    readonly volumes?: DockerVolume[];
    /**
     * Named docker volumes to attach to the container.
     *
     * @default - no named volumes
     */
    readonly namedVolumes?: DockerNamedVolume[];
    /**
     * The container network to attach to (`--network`).
     *
     * @default - the default docker network
     */
    readonly network?: string;
    /**
     * The platform to run the container as (`--platform`).
     *
     * @default - the host platform
     */
    readonly platform?: string;
    /**
     * A `--security-opt` value passed to the container.
     *
     * @default - none
     */
    readonly securityOpt?: string;
}
/**
 * Options for {@link dockerExec}.
 */
export interface DockerExecOptions {
    /**
     * Capture standard output instead of forwarding it to standard error.
     *
     * @default false
     */
    readonly captureStdout?: boolean;
}
/**
 * Renders a named volume as a `--mount` value that tolerates `,` and `"` in fields.
 */
export declare function namedVolumeSpec(volume: DockerNamedVolume): string;
/**
 * Renders a bind mount as a `--mount` value that tolerates `:`, `,` and `"` in host paths.
 */
export declare function bindMountSpec(volume: DockerVolume): string;
/**
 * Renders docker arguments for error messages without secret-bearing values.
 *
 * Redaction is applied to every matching flag in the argument list, including
 * flags inside the user command, so it can over-redact but never under-redact.
 */
export declare function redactArgs(args: string[]): string[];
/**
 * Throws when an image reference would be parsed by docker as a flag.
 */
export declare function assertImageReference(image: string): void;
/**
 * Runs a docker command and throws on a non-zero exit.
 *
 * Standard output is forwarded to standard error unless `captureStdout` is set,
 * so long build logs cannot overflow the capture buffer.
 */
export declare function dockerExec(args: string[], options?: DockerExecOptions): DockerExecResult;
/**
 * Run a docker image once with the given options and wait for it to exit.
 *
 * The `DockerImage` class in `./bundling` is the public entry point.
 */
export declare function runDockerImage(image: string, options?: DockerRunOptions): void;
