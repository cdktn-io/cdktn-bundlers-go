import type { DockerRunOptions } from "./docker";
/**
 * A docker image referenced from a registry.
 */
export declare class DockerImage {
    /**
     * The image reference (name and optional tag) this instance runs.
     */
    readonly image: string;
    /**
     * Reference an image by name or by name and tag from a registry.
     */
    static fromRegistry(image: string): DockerImage;
    private constructor();
    /**
     * Run the image once with the given options and wait for it to exit.
     */
    run(options?: DockerRunOptions): void;
}
