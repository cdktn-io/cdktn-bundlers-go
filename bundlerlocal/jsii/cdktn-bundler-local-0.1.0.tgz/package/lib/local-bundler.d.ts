import { BundleOptions, BundleOutputType, BundleResult, IAssetBundler } from "cdktn";
/**
 * Configuration for {@link LocalBundler}.
 */
export interface LocalBundlerProps {
    /**
     * The command to run on the host, as an argv array.
     *
     * The first element is the program; the rest are its arguments. The command
     * runs with `ASSET_INPUT_DIR` set to the source and `ASSET_OUTPUT_DIR` set
     * to the output directory, and it is expected to write the built artifact
     * into `ASSET_OUTPUT_DIR`.
     */
    readonly command: string[];
    /**
     * Environment variables to set for the command.
     *
     * @default - only the caller's environment plus `ASSET_INPUT_DIR` and
     * `ASSET_OUTPUT_DIR`
     */
    readonly environment?: {
        [key: string]: string;
    };
    /**
     * The working directory the command runs in.
     *
     * @default - the asset source directory, or its parent for a file source
     */
    readonly workingDirectory?: string;
    /**
     * The shape of the artifact the command writes to `ASSET_OUTPUT_DIR`.
     *
     * `DIRECTORY` stages the output directory. `FILE` requires the command to
     * write exactly one file and stages that file.
     *
     * @default - `FILE` when `outputFileName` is set, otherwise `DIRECTORY`
     */
    readonly outputType?: BundleOutputType;
    /**
     * Extra content folded into the bundler key so a change to it invalidates
     * the asset hash even when the source and command are unchanged.
     *
     * @default - nothing extra is folded in
     */
    readonly extraHash?: string;
    /**
     * The file name to stage a single-file artifact under.
     *
     * Only meaningful when the result is a single file staged as
     * `AssetType.FILE`. Without it, a file produced from a directory source is
     * staged under the source directory's basename.
     *
     * @default - the basename of the asset source path
     */
    readonly outputFileName?: string;
}
/**
 * Runs a build command on the host and stages its output as a CDK for
 * Terraform asset.
 *
 * The command is spawned with the asset source and a caller-owned output
 * directory exposed through the `ASSET_INPUT_DIR` and `ASSET_OUTPUT_DIR`
 * environment variables. Unlike a container bundler, the build runs directly
 * on the machine performing the synth, so the required toolchain must already
 * be installed there.
 */
export declare class LocalBundler implements IAssetBundler {
    readonly bundlerKey?: string;
    readonly outputFileName?: string;
    private readonly command;
    private readonly environment?;
    private readonly workingDirectory?;
    private readonly outputType;
    constructor(props: LocalBundlerProps);
    bundle(options: BundleOptions): BundleResult;
}
