import { SpawnSyncOptions, SpawnSyncReturns } from "child_process";
/**
 * `spawnSync` that resolves Windows `.cmd`/`.bat` shims (as created for
 * `npm`, `npx`, `pnpm`, and everything under `node_modules/.bin`) through
 * `cmd.exe` the way a shell would, so they run without the caller having to
 * invoke a shell itself. A thin pass-through to `child_process.spawnSync`
 * on every other platform.
 */
export declare function spawnSyncCrossPlatform(command: string, args: string[], options: SpawnSyncOptions): SpawnSyncReturns<string | Buffer>;
